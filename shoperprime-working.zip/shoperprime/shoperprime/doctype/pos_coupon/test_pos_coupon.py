# Copyright (c) 2021, Jawahar R Mallah and Contributors
# See license.txt

# import frappe
import unittest

class TestPOSCoupon(unittest.TestCase):
	pass
