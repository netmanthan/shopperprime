# Copyright (c) 2022, Jawahar R Mallah and Contributors
# See license.txt

# import frappe
import unittest

class TestDeliveryCharges(unittest.TestCase):
	pass
